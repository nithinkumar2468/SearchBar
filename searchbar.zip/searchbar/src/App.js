import {useState} from "react";
import './App.css';
import SearchBar from './Component/SearchBar';
import SearchResults from './Component/SearchResults';

function App() {
  const [results,setResults]=useState([]);

  return (
    <div className="App">
      <div className="search-bar">
        <SearchBar setResults={setResults}/>
      </div>
      <SearchResults results={results}/>
    </div>
  );
}

export default App;
