import "./Searchlist.css";
function Searchlist({result}){
    return(
        <div className="searchlist" onClick={(e)=>alert(`You Clicked on ${result.p_name}`)}>
            {result.p_name}
        </div>
    )
}
export default Searchlist;